import React, { Component } from "react";
import ToggleSwitch from "./components/ToggleSwitch";


class App extends Component {
render() {
	return (
	<React.Fragment>
		<ToggleSwitch label="1" onClick="{}" />
            <ToggleSwitch label="2" />
            <ToggleSwitch label="3" />
            <ToggleSwitch label="4" />
            <ToggleSwitch label="5" />
            <ToggleSwitch label="6" />
            <ToggleSwitch label="7" />
            <ToggleSwitch label="8" />
	</React.Fragment>
    
      
	);

      
}
}

export default App;



 
